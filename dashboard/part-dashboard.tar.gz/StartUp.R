

library(shiny)

# ## CHECK WOKING DIRECTORY!
setwd(here::here("dashboard"))

runApp()
